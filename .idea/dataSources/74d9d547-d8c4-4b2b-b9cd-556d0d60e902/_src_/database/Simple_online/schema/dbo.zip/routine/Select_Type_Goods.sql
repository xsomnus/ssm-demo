CREATE proc [dbo].[Select_Type_Goods]
@cGroupTypeNo     varchar(50),
@Number_of_pages  varchar(50),
@cStoreNo         varchar(20),
@UserNo           varchar(20)
as
declare @discount_rate varchar(50)
select  @discount_rate=isnull(discount_rate,1) from Simple_online.dbo.User_Table where UserNo=@UserNo  
if(@discount_rate is not null) 
begin
SELECT TOP 10  * FROM (select  ROW_NUMBER() OVER (ORDER BY c.Show_Level desc) AS RowNumber,
 c.* from  (select c.cGoodsNo,c.cGoodsName,c.bFresh,c.fNormalPrice,c.fVipPrice,c.Show_Level,
 bOnLine_Price=convert(money, c.bOnLine_Price) * @discount_rate  ,c.cUnit,c.cSpec,d.cGoodsImagePath from  Posmanagement_main.dbo.T_GroupType a  ,Posmanagement_main.dbo.T_GroupType_GoodsType  b ,
 posmanagement_main.dbo.t_cStoreGoods c, posmanagement_main.dbo.T_Goods d 
 where a.cGroupTypeNo=@cGroupTypeNo and a.cGroupTypeNo=b.cGroupTypeNo and c.cGoodsTypeno=b.cGoodsTypeno 
 and cStoreNo=@cStoreNo and c.cGoodsNo=d.cGoodsNo and c.bOnLine='1' ) c) as A  WHERE RowNumber > 10 *(convert(int,@Number_of_pages)-1)
 end
 else
  begin
  SELECT TOP 10  * FROM (select  ROW_NUMBER() OVER (ORDER BY c.Show_Level desc) AS RowNumber,
 c.* from  (select c.cGoodsNo,c.cGoodsName,c.bFresh,c.fNormalPrice,c.fVipPrice,c.Show_Level,
  c.bOnLine_Price  ,c.cUnit,c.cSpec,d.cGoodsImagePath from  Posmanagement_main.dbo.T_GroupType a  ,Posmanagement_main.dbo.T_GroupType_GoodsType  b ,
 posmanagement_main.dbo.t_cStoreGoods c, posmanagement_main.dbo.T_Goods d 
 where a.cGroupTypeNo=@cGroupTypeNo and a.cGroupTypeNo=b.cGroupTypeNo and c.cGoodsTypeno=b.cGoodsTypeno 
 and cStoreNo=@cStoreNo and c.cGoodsNo=d.cGoodsNo and c.bOnLine='1' ) c) as A  WHERE RowNumber > 10 *(convert(int,@Number_of_pages)-1)
 end
GO
