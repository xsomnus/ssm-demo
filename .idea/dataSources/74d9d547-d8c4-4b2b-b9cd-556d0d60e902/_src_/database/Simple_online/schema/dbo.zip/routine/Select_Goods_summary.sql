CREATE proc [dbo].[Select_Goods_summary]
@start_time datetime,
@end_time datetime,
@cGoodsNo varchar(50)
   
as

  ---查询所有门店对应的单子
if(select object_id('tempdb..#cSheetno_table')) is not null drop table 	#cSheetno_table
  select cSheetno,Date_time,Send_cStoreNo into #cSheetno_table
 from dbo.Order_Table  where Pay_state='1'  and CONVERT(varchar(10),Date_time,20) between @start_time  and @end_time

  -- select * from #cSheetno_table
--查询单子对应所有的商品

if(select OBJECT_ID('tempdb..#Ordergoods_Details')) is not null drop table #Ordergoods_Details

select  a.cSheetno,a.Date_time,a.Send_cStoreNo,b.cGoodsNo,b.cGoodsName,b.Num,b.Last_Price,b.Last_Money
 into #Ordergoods_Details
 from  #cSheetno_table a ,dbo.Order_Details b  where a.cSheetno=b.cSheetno

  -- select * from #Ordergoods_Details
--根据商品编号

if(select OBJECT_ID('tempdb..#Ordergoods_summary')) is not null drop table #Ordergoods_summary

 select cGoodsNo,cGoodsName,Send_cStoreNo,num=sum(num)
 
 into #Ordergoods_summary from #Ordergoods_Details where cGoodsNo=@cGoodsNo 
 
 group by cGoodsNo,cGoodsName,Send_cStoreNo 
 
  --select * from #Ordergoods_summary
 
 select cStoreNo=a.Send_cStoreNo ,a.num,b.cStoreName  from #Ordergoods_summary a , Posmanagement_main.dbo.t_store b
 
 where a.Send_cStoreNo=b.cStoreNo
GO
