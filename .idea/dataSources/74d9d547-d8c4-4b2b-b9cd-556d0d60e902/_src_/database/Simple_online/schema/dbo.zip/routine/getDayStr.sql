

create    function [dbo].[getDayStr] 
(@theDatetime datetime) returns varchar(16)
AS
begin
return (datename(yyyy,@theDatetime)+'-'+
       case when len(datename(mm,@theDatetime))=1
            then '0'+datename(mm,@theDatetime)
            else datename(mm,@theDatetime)
       end
       +'-'+
       case when len(datename(dd,@theDatetime))=1
            then '0'+datename(dd,@theDatetime)
            else datename(dd,@theDatetime)
       end
       )       
end


GO
