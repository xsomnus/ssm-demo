create proc [dbo].[p_O_WalletReg]
@Buyer_id varchar(64),
@BuyerName varchar(32),
@BuyerPwd varchar(32),
@PayPwd varchar(32),
@Tel varchar(32),
@Email varchar(32),
@cRealName varchar(32),
@Cid varchar(32),
@Money_MD5 text,
@return int output
as
begin
/*
  返回状态：1表示当前用户名已注册；
            2表示当前手机号已注册；
            3表示邮箱已注册；
            0表示注册失败；
            否则返回当前注册用户ID
            5是注册成功
*/
  begin try 
  begin tran
    if exists (select BuyerName from PS_Wallet.dbo.W_bBuyer where BuyerName=@BuyerName)  -- 判定UesrName是否已经被使用过
	begin
	    set @return=1
	end else
	begin	
	  if exists (select BuyerName from PS_Wallet.dbo.W_bBuyer where Tel=@Tel)  -- 判定手机是否已经被使用过
	  begin
	     set @return=2
	  end else
	  begin
	      if exists (select BuyerName from PS_Wallet.dbo.W_bBuyer where Email=@Email)  -- 判定邮箱是否已经被使用过
		  begin
			 set @return=3
		  end else
		  begin
		      insert into PS_Wallet.dbo.W_bBuyer(Buyer_id,WServerID,BuyerName,BuyerPwd,PayPwd,Tel,Email,cRealName,Cid,Beizhu,WStatus,Money_MD5)
		      values(@Buyer_id,1,@BuyerName,@BuyerPwd,@PayPwd,@Tel,@Email,@cRealName,@Cid,convert(varchar(100),GETDATE(),20),1,@Money_MD5)
		    
		      set @return=5
		  end
	  end
	end  
	
    commit tran
    
	end try
	begin catch  
	   rollback  
	  set @return=0
	end catch
end
GO
