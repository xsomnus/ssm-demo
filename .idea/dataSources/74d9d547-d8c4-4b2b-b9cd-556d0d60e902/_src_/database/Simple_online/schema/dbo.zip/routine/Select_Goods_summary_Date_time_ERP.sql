CREATE proc [dbo].[Select_Goods_summary_Date_time_ERP]  
    --exec Select_Goods_summary_Date_time_ERP '2017-05-04','2017-05-06'
@start_time datetime,
@end_time datetime
as
  ---查询所有在这个时间段的所有门店对应的单子,并且已经支付
if(select object_id('tempdb..#cSheetno_table')) is not null drop table 	#cSheetno_table
  select cSheetno,Date_time,Send_cStoreNo into #cSheetno_table
  from dbo.Order_Table  where Pay_state='1'  and CONVERT(varchar(10),Date_time,20) between @start_time  and @end_time 
  
--查询单子对应所有的商品

if(select OBJECT_ID('tempdb..#Ordergoods_Details')) is not null drop table #Ordergoods_Details

 select  a.cSheetno,a.Date_time,a.Send_cStoreNo,b.cGoodsNo,b.cGoodsName,b.Num,b.Last_Price,b.Last_Money
 into #Ordergoods_Details
 from  #cSheetno_table a ,dbo.Order_Details b  where a.cSheetno=b.cSheetno

  -- select * from #Ordergoods_Details
  
 
--汇总商品并查出商品类别

if(select OBJECT_ID('tempdb..#Ordergoods_summary')) is not null drop table #Ordergoods_summary

 select a.cGoodsNo,a.cGoodsName,b.cBarcode, b.cGoodsTypeNo,num=sum(a.num)
 
 into #Ordergoods_summary from #Ordergoods_Details a,Posmanagement_main.dbo.t_goods b where a.cGoodsNo=b.cGoodsNo 
 
 group by a.cGoodsNo,a.cGoodsName,b.cBarcode,b.cGoodsTypeNo
 
   --查询此(传过来大类)商品下的所有商品类别
  if(select OBJECT_ID('tempdb..#Ordergoods_type')) is not null drop table #Ordergoods_type 
  
   select DiSTINCT a.cGoodsTypeNo,b.cGroupTypeName into #Ordergoods_type 
   from Posmanagement_main.dbo.T_GroupType_GoodsType a, Posmanagement_main.dbo.T_GroupType  b
   where a.cGroupTypeNo=b.cGroupTypeNo 
  
  
  
 select a.*,b.cGroupTypeName,c.cUnit,cSpec,c.fCKPrice,c.fNormalPrice from #Ordergoods_summary a, #Ordergoods_type  b, Posmanagement_main.dbo.t_goods  c where a.cGoodsTypeno=b.cGoodsTypeNo
 and a.cGoodsNo=c.cGoodsNo

GO
