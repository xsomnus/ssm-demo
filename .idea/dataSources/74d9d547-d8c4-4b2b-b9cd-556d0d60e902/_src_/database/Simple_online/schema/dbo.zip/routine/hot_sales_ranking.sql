CREATE proc Hot_sales_ranking  
--热销排行
as
SET  NOCOUNT ON
select Top 10  b.cGoodsNo,count(*) purchaseTimes, 
c.cGoodsName,c.bFresh,c.fNormalPrice,c.fVipPrice,
c.bOnLine_Price ,c.cUnit,c.cSpec, d.cGoodsImagePath,
c.Show_Level  from dbo.Order_Table a, dbo.Order_Details b,
posmanagement_main.dbo.t_cStoreGoods c, posmanagement_main.dbo.T_Goods d 
 where  a.cSheetno = b.cSheetno and b.cGoodsNo = c.cGoodsNo  and a.Pay_state<>'0'
 and c.cStoreNo = '000' and c.cGoodsNo = d.cGoodsNo and c.bOnLine='1' and a.Date_time >= convert(varchar(10),getdate() - 30,120)
  group by b.cGoodsNo, c.cGoodsName,c.bFresh,c.fNormalPrice,c.fVipPrice,c.bOnLine_Price ,
  c.cUnit,c.cSpec, d.cGoodsImagePath,c.Show_Level  order by purchaseTimes DESC
GO
